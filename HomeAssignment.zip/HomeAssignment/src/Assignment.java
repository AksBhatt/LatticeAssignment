import java.util.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Collectors;

public class Assignment {

    public static void getTextFromFile(String input_file_name,String common_words,int num) throws IOException {
        if(input_file_name.length() ==0 ){
            return;
        }

        List<String> finalResult = new LinkedList<>();

        Map<String,Integer> result = new HashMap<>();

        if(!Files.exists(Paths.get(input_file_name))){
            System.err.println("file not exist: " + input_file_name);
            return;
        }

        String content = new String(Files.readAllBytes(Paths.get(input_file_name)));

        content = content.toLowerCase(Locale.ROOT);

        String[] words = content.split("\\W+");

        String commonWords = new String(Files.readAllBytes(Paths.get(common_words)));

        commonWords = commonWords.toLowerCase(Locale.ROOT);

        String[] commonwords = commonWords.split(System.lineSeparator());

        for(String word:words){
            if(!word.equals("") && !word.equals(" ") && !(Arrays.asList(commonwords)).contains(word)){
                result.put(word,result.getOrDefault(word,0)+1);
            }
        }

        Map<String,Integer> resultantMap = new HashMap<>();

        result.entrySet().removeIf(e -> e.getKey().length() == 1);

        Map<String,Integer> printMap= new HashMap<>();

        printMap = result.entrySet().stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .collect(Collectors.toMap(
                        Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));

        System.out.println("The values are\n");
        for(Map.Entry<String,Integer> entry:printMap.entrySet()){
            System.out.println(entry.getKey()+" => "+entry.getValue());
        }


        resultantMap = result.entrySet()
                .stream()
                .sorted(Comparator.comparing(e -> e.getValue(), Comparator.reverseOrder()))
                .limit(num)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        System.out.println("The resultant map is "+resultantMap);

    }


    public static void main(String[] args) throws IOException {
        if(args.length == 2)
        {
            getTextFromFile(args[0],args[1],2);
        }
        else {
            getTextFromFile("/Applications/HomeAssignment/src/alice_in_wonderland.txt","/Applications/HomeAssignment/src/1-1000.txt",2);
        }

    }


}
